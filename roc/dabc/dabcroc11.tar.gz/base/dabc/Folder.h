/********************************************************************
 * The Data Acquisition Backbone Core (DABC)
 ********************************************************************
 * Copyright (C) 2009- 
 * GSI Helmholtzzentrum fuer Schwerionenforschung GmbH 
 * Planckstr. 1
 * 64291 Darmstadt
 * Germany
 * Contact:  http://dabc.gsi.de
 ********************************************************************
 * This software can be used under the GPL license agreements as stated
 * in LICENSE.txt file which is part of the distribution.
 ********************************************************************/
#ifndef DABC_Folder
#define DABC_Folder

#ifndef DABC_Basic
#include "dabc/Basic.h"
#endif

#ifndef DABC_collections
#include "dabc/collections.h"
#endif

namespace dabc {

   class Folder : public Basic {
      public:
         Folder(Basic* parent, const char* name, bool owner = false);
         virtual ~Folder();

         virtual const char* MasterClassName() const { return "Folder"; }
         virtual const char* ClassName() const { return "Folder"; }

         virtual void AddChild(Basic* child);
         virtual void RemoveChild(Basic* child);
         void DeleteChilds(int appid = -1, const char* classname = 0);
         void RemoveChilds();

         unsigned NumChilds() const;
         Basic* GetChild(unsigned n) const;
         Basic* FindChild(const char* name) const;
         bool IsChild(Basic* obj) const;
         bool IsOwner() const { return fOwner; }

         Folder* GetFolder(const char* name, bool force = false, bool isowner = true);

         virtual bool Store(ConfigIO &cfg);
         virtual bool Find(ConfigIO &cfg);

         static std::string GetPathName(const char* path);
         static const char* GetObjectName(const char* path);

      protected:

         virtual void _SetParent(Mutex* mtx, Basic* parent);

         void StoreChilds(ConfigIO &cfg);

         Basic* _FindChild(const char* name) const;

      private:
         PointersVector    fChilds;
         bool              fOwner;
   };
}

#endif
