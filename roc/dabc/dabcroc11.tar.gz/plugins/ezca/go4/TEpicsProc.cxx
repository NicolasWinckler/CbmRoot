// $Id: TEpicsProc.cxx 614 2010-04-13 15:39:33Z linev $
//-----------------------------------------------------------------------
//       The GSI Online Offline Object Oriented (Go4) Project
//         Experiment Data Processing at EE department, GSI
//-----------------------------------------------------------------------
// Copyright (C) 2000- GSI Helmholtzzentrum f�r Schwerionenforschung GmbH
//                     Planckstr. 1, 64291 Darmstadt, Germany
// Contact:            http://go4.gsi.de
//-----------------------------------------------------------------------
// This software can be used under the license agreements as stated
// in Go4License.txt file which is part of the distribution.
//-----------------------------------------------------------------------

#include "TEpicsProc.h"

#include <stdlib.h>
#include "Riostream.h"

#include "TH1.h"
#include "TH2.h"
#include "TCutG.h"
#include "TCanvas.h"
#include "TLine.h"

#include "TGo4MbsEvent.h"
#include "TGo4WinCond.h"
#include "TGo4PolyCond.h"
#include "TGo4CondArray.h"
#include "TGo4Picture.h"
#include "TGo4StepFactory.h"
#include "TGo4Analysis.h"
#include "TGo4Version.h"


//***********************************************************
TEpicsProc::TEpicsProc() : TGo4EventProcessor()
{
}

//***********************************************************
TEpicsProc::~TEpicsProc()
{
   cout << "**** TEpicsProc: Delete instance " << endl;
}

//***********************************************************
// this one is used in standard factory
TEpicsProc::TEpicsProc(const char* name) : TGo4EventProcessor(name)
{
   cout << "**** TEpicsProc: Create instance " << name << endl;


   for(int i=0;i<_NUM_LONG_RECS_;i++) {
	   fLongRecords[i] = MakeTH1('I', Form("LongRecs/Long%02d",i), Form("Long Record %2d",i), 5000, 1., 5000);
   }

   for(int i=0;i<_NUM_DOUBLE_RECS_;i++) {
   	   fDoubleRecords[i] = MakeTH1('I', Form("DoubleRecs/Double%02d",i), Form("Double Record %2d",i), 5000, 1., 5000);
      }

}

//-----------------------------------------------------------
// event function
Bool_t TEpicsProc::BuildEvent(TGo4EventElement*)
{  // called by framework. We dont fill any output event here at all

   if ((GetInputEvent()==0) || (GetInputEvent()->IsA() != TGo4MbsEvent::Class())) {
      cout << "TEpicsProc: no input MBS event found!" << endl;
      return kFALSE;
   }

   TGo4MbsEvent* evnt = (TGo4MbsEvent*) GetInputEvent();

   if(evnt->GetTrigger() > 11) {
      cout << "**** TEpicsProc: Skip trigger event" << endl;
      return kFALSE;
   }

   evnt->ResetIterator();
   TGo4MbsSubEvent *psubevt(0);
   while((psubevt = evnt->NextSubEvent()) != 0) { // loop over subevents

	   if (psubevt->GetProcid() != 8)
      			continue; // only evaluate epics events here

	   if(_VARPRINT_)
	  		   {
	  			   cout <<endl<<"Print Event number:"<< evnt->GetCount()<< endl;
	  		   }

	   int* pdata= psubevt->GetDataField();
	   // first payload: header with number of long records
	   int numlong=*pdata++;
	   for(int i=0; i<numlong;++i)
	   {
		   long val=*pdata++;
		   if(_VARPRINT_)
		   {
			   cout <<"Long "<<i<<"="<< val<< endl;
		   }
		   if(i>=_NUM_LONG_RECS_) continue;
		   fLongRecords[i]->Fill(val);
	   }
	   int numdub=*pdata++;
	   for(int i=0; i<numdub;++i)
	   {
		   double val=*pdata++;
		   if(_VARPRINT_)
		   {
			   cout <<"Double "<<i<<"="<< val<< endl;
		   }
		   if(i>=_NUM_DOUBLE_RECS_) continue;
		   fDoubleRecords[i]->Fill(val);
	   }

   }// while

   return kTRUE;
}
